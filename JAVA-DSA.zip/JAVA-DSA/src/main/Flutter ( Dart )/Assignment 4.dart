//Q1)
 
main() {
   for (int i = 31; i<=55; i++) {
       print(i);
   }
 }

//Q2

 main() {
   for (int i = 63; i <= 123; i++) {
     if (i % 9 == 0) {
       print(i);
     }
   }
 }

//Q3)
 main() {
   int sum = 0;
   for (int i = 20; i <= 120; i++) {
     if (i % 2 == 1) {
       sum += i;
     }
   }
   print(sum);
 }

//Q4)
main() {
  for (int i = 100; i<=120; i++) {
      print(i*i);
  }
}

//Q5)
 main() {
   for (int i = 1; i <= 100; i++) {
     if (i % 4 == 0 && i % 3 == 0) {
       print(i);
     }
   }
 }

//Q6
main() {
  for (int i = 20; i <= 50; i++) {
    if (i % 4 != 0 && i % 4 == 3) {
      print(i);
    }
  }
}

//Q7)
main() {
  for (int i = 20; i <= 60; i++) {
    if (i % 7 == 0) {
      print(i*i*i);
    }
  }
}

//Q8)
main() {
  int sum = 0;
  for (int i = 1; i <= 10; i++) {
    sum += 12 * i;
  }
  print(sum);
}

//Q9)
main() {
  int sum = 0;
  for (int i = 1; i <= 15; i++) {
      sum += i * i;
  }
  print(sum);
}

//Q10
main() {
  for (int i = 20; i <= 70; i++) {
    if (i % 2 != 0) {
      print(i * i);

    } else {
      print(i * i * i); 
    }
  }
}
