/* ﻿
Array Rotation:

Given an integer array A of size N and an integer B, you have to return
the same array after rotating it B times towards the right.

Problem Constraints:
1<=N<=10^5
1<=arr[i]<=10^9
1<=B<=10^9

Ex. A=[1,2,3,4]
B = 2
o/p: [3,4,1,2]

Ex. A=[2,5,6]
B = 1
o/p: [6,5,2] 
*/

