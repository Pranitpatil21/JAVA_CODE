//Q1
main() {
  int i = 1;
  while (i <= 10) {
    print(i*4);
    i++;
  }
}

//Q2
main() {
  int i = 10;
  while (i >= 1) {
    print(i*5);
    i--;
  }
}
//Q3
main() {
  int i = 10;
  while (i>0) {
    i--;
    print(i);
  }
}

//Q4
main() {
  int i = 50;
  while (i >= 30) {
    if (i % 2 == 0) {
      print(i);
    }
    i--;
  }
}

//Q5
main() {
  int i = 40;
  while (i <= 50) {
    if (i % 2 == 0) {
      print(i*i);
    }
    i++;
  }
}
//Q6
main() {
  int i = 20;
  while (i >= 10) {
    if (i % 2 != 0) {
      print(i*i);
    }
    i--;
  }
}
//Q7
main() {
  int i = 40;
  while (i <= 50) {
    if (i % 2 != 0) {
      print(i * i);
    } else {
      print(i * i * i);
    }
    i++;
  }
}
//Q8
main() {
  int mul = 1;
  int i = 10;
  while (i >= 1) {
    if (i % 2 == 1) {
      mul *= i;
    }
    i--;
  }
  print(mul);
}
//Q9
main() {
  int numDays = 7;
  while (numDays >= 0) {
    if (numDays > 0) {
      print("$numDays remaining");
    } else {
      print("$numDays days Assignment is OverDue");
    }
    numDays--;
  }
}

//Q10
main() {
  int i = 1;
  while (i <= 10) {
    if (i == 5) {
      i++;
      continue;
    }
    print(i);
    i++;
  }
}

