// Q1)
 import "dart:io";
 main() {
   int ramSize = int.parse(stdin.readLineSync()!);

   if (ramSize <= 4) {
     print("Can not run a project ");
   } else {
     print("Can run a flutter project ");
   }
 }

// Q2)
import "dart:io";
main() {
  int x = int.parse(stdin.readLineSync()!);
  if (x == 1) {
    print("Voilet");
  } else if (x == 2) {
    print("Indigo");
  } else if (x == 3) {
    print("Blue");
  } else if (x == 4) {
    print("Green");
  } else if (x == 5) {
    print("Yellow");
  } else if (x == 6) {
    print("Orange");
  } else if (x == 7) {
    print("Red");
  } else {
    print("Invalid Input");
  }
}

//Q3)
import "dart:io";
main() {
  int x = int.parse(stdin.readLineSync()!);
  if (x>=30 && x<=50) {
    print("Number is In Correct Range");
  } else {
    print("Invalid Number");
  }
}

//Q4)
import "dart:io";
main() {
  int x = int.parse(stdin.readLineSync()!);
  if (x>=16 && x%2==0) {
    print("Correct Number");
  } else {
    print("Incorrect Number");
  }
}

//Q5)
import "dart:io";
main() {
  int x = int.parse(stdin.readLineSync()!);
  if (x%3 == 2) {
    print("Remainder is equal to 2");
  } else {
    print("Remainder is Less than 2");
  }
}

//Q6)
import "dart:io";
main() {
  double bmi = double.parse(stdin.readLineSync()!);
  if (bmi <= 18.5) {
    print("Underweigth");
  } else if(bmi> 18.5 && bmi<=24.9) {
    print("normal");
  } else if(bmi>=25.0 && bmi<=29.9) {
    print("OverWeight");
  }else if(bmi>=30.0 && bmi<=34.9) {
    print("Obese");
  }else {
    print("Extreme Obese");
  }
}

//Q7)
import "dart:io";
main() {
  int x  = int.parse(stdin.readLineSync()!);
  if (x >=8 ) {
    print("you Can not Enter in the Lift");
  } else {
    print("You can Enter the lift ");
  }
}

//Q8)
import "dart:io";
main() {
  String? vehicle = stdin.readLineSync();
  if (vehicle == "Bike" || vehicle == "bike" || vehicle == "BIKE") {
    print("Go to Parking 2");
  } else if (vehicle == "Scooter" || vehicle == "scooter" || vehicle == "SCOOTER") {
    print("Go to Parking 1");
  } else {
    print("Enter valid Vehicle");
  }
}

//Q9)
import "dart:io";
main() {
  int x = int.parse(stdin.readLineSync()!);
  if (x >= 0 && x < 25) {
    print("Your grade is D");
  } else if (x >= 25 && x < 50) {
    print("Your grade is C");
  } else if (x >= 50 && x < 75) {
    print("Your grade is B");
  } else if (x >= 75 && x <= 100) {
    print("Your grade is A");
  } else {
    print("Wrong Input");
  }
}

//Q10)
import "dart:io";

main() {
  int percentage = int.parse(stdin.readLineSync()!);
  double cgpa = double.parse(stdin.readLineSync()!);
  if (percentage >= 70 && cgpa >= 7.0) {
    print("You are eligible");
  } else {
    print("You are not eligible");
  }
}


  