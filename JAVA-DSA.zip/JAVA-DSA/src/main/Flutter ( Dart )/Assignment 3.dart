//Q1)
main() {
  for (int i = 1; i <= 10; i++) {
    print(i);
  }
}

//Q2)
main() {
  for(int j = 1; j <= 100; j++) {
    print(j);
  }
}

//Q3)
main() {
  for(int j = 0; j <= 10; j++) {
    print(j+100);
  }
}

//Q4)
main() {
  for (int j = 1; j <= 100; j++) {
    if (j % 2 == 0) {
      print(j);
    }
  }
}

//Q5)
main() {
  for (int j = 1; j <= 50; j++) {
    if (j % 2 != 0) {
      print(j);
    }
  }
}

//Q6)
main() {
  for (int j = 100; j >= 1; j--) {
    print(j);
  }
}

//Q7)
main() {
  for (int j = 1; j <= 10; j++) {
    print(j*12);
  }
}

//Q8)
  main() {
    for (int j = 10; j >= 1; j--) {
      print(j*12);
    }
  }

//Q9)
main() {
  int sum = 0;
  for (int j = 1; j <= 10; j++) {
    sum += j;
  }
  print(sum);
}

//Q10
main() {
  int product = 1;
  for (int j = 1; j <= 10; j++) {
    product *= j;
  }
  print(product);
}

