 // Q1)
import "dart:io";
 main() {
  var x;
  x = int.parse(stdin.readLineSync()!);
  if (x % 2 == 0) {
    print("$x Number is Even ");
  } else {
    print("$x Number is Odd ");
  }
}

// Q2)
import "dart:io";

main() {
  var x;
  print("Enter a Number");
  x = int.parse(stdin.readLineSync()!);
  if (x == 10) {
    print("Number is equal to 10");
  } else if (x < 10) {
    print("$x Is Smaller than 10");
  } else {
    print("$x Is Greater than 10");
  }
}

 // Q3) 
 import "dart:io";

 main() {
  int age;
  print("Enter a Age");
  age = int.parse(stdin.readLineSync()!);
  if (age >= 18) {
    print("You can Cast Vote ");
   } else {
     print("You Cannot Cast Vote ");
   }
 }
    
  // Q4)
  import "dart:io";
  main() {
    print("Enter a Number");
    var num = int.parse(stdin.readLineSync()!);
    if (num == 0) {
      print("Number is Zero");
    } else if (num < 0) {
      print("$num is Negative");
    } else {
      print("$num is Positive");
    }
  }

  // Q5)
   import "dart:io";
   main() {
   var c = stdin.readLineSync();
   if (c == "A" || c == "E" || c == "I" || c == "O" || c == "U" ||
     c == "a" || c == "e" || c == "i" || c == "o" || c == "u") {
     print("$c is Vowel ");
   } else {
      print("$c is consonant ");
     }
   }
  
   // Q6)
   import "dart:io";
   main() {
     var x = int.parse(stdin.readLineSync()!);
     if (x == 0) {
       print("Zero");
     } else if (x == 1) {
       print("One");
     } else if (x == 2) {
       print("Two");
     } else if (x == 3) {
       print("Three");
     } else if (x == 4) {
       print("Four");
     } else if (x == 5) {
       print("Five");
     } else {
       print("$x is greater than 5");
     }
   }
   
   // Q7)
   import "dart:io";
   main() {
     var month = int.parse(stdin.readLineSync()!);
     if (month == 1) {
       print("January has 31 days");
     } else if (month == 2) {
       print("February has 29 days");
     } else if (month == 3) {
       print("March has 31 days");
     } else if (month == 4) {
       print("April has 30 days");
     } else if (month == 5) {
       print("May has 31 days");
     }else if (month == 6) {
       print("June has 30 days");
     }else if (month == 7) {
       print("July has 31 days");
     }else if (month == 8) {
       print("August has 31 days");
     }else if (month == 9) {
       print("September has 30 days");
     }else if (month == 10) {
       print("October has 31 days");
     }else if (month == 11) {
       print("November has 30 days");
     }else if (month == 12) {
       print("December has 31 days");
     } else {
       print("Invalid Month");
     }
   }
  
   // Q8)
   import "dart:io";

   main() {
     int num = int.parse(stdin.readLineSync()!);
     if (num % 3 == 0 && num % 5 == 0) {
       print("Divisible by Both");
     } else if (num % 3 == 0) {
       print("Divisible by 3");
     } else if (num % 5 == 0) {
       print("Divisible by 5");
     } else {
       print("Not Divisible by Both");
     }
   }
   
   // Q9)
   import "dart:io";
    main() {
     print("Press 1 For Upper Stand ticket");
     print("Press 2 For Middle Stand ticket");
     print("Press 3 For Lower Stand ticket");
     print("Press Any For Other ticket");
     int x = int.parse(stdin.readLineSync()!);

     if (x == 1) {
       print("Please pay 2000 rupees");
     } else if (x == 2) {
       print("Please pay 3000 rupees.");
     } else if (x == 3) {
       print("Please pay 7000 rupees.");
     } else {
       print("Please pay 2500 rupees.");
     }
   }

  // Q 10)
    import "dart:io";
    main() {
      print("Enter Unit");
      int x = int.parse(stdin.readLineSync()!);

      if (x <= 90) {
        print("No Charge");
      } else if (91 <= x && x <= 180) {
        print(x*6);
      } else if (x>= 181 && x <= 250) {
        print(x*10);
      } else {
        print(x*15);
      }
    }


