import java.util.*;

class StackUsingArray{
 int maxSize;
 int stackArr[];
 int top = -1;   //invalid Index
 StackUsingArray(int size){
     this.stackArr = new int[size];   //arraysize
     this.maxSize = size;
 }
 // Push Operation
 void push(int data){
     if(top == maxSize-1){                           // here stack is full we can not add it more
         System.out.println("Stack OverFlow");
     }else{
         top++;
         stackArr[top] = data;
     }
 }
 //empty
    boolean empty(){
      return top == -1; //if top == -1  then it will return true otherwise it will return false
    }
 //pop Operation
    int pop(){
       if(empty()){
           System.out.println("Stack is Empty");
           return -1;
       }else{
           int val = stackArr[top];
           top--;
           return val;
       }
    }
 //peek Operation
    int peek(){
        if(empty()){
            System.out.println("Stack is Empty");
            return -1;
        }else{
           return stackArr[top];
        }
    }
//Size
   int size(){
     return top+1;
   }
//Print Stack
   void printStack(){
     if(empty()){
         System.out.println("Stack is empty");
     }else {
         System.out.print(" [ ");
         for(int val = 0;val <= top ;val++){
             System.out.print(stackArr[val]+" ");
         }
         System.out.println("] ");
     }
   }
}
class Client{
    public static void main(String[] args) {
        System.out.println("Enter Size");
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        StackUsingArray s = new StackUsingArray(size);
        char ch;
        do{
            System.out.println("1.Push");
            System.out.println("2.Pop");
            System.out.println("3.peek");
            System.out.println("4.size");
            System.out.println("5.isEmpty");
            System.out.println("6.Print Stack");
            System.out.print("Enter Your Choice");
            int choice = sc.nextInt();
            switch (choice){

                case 1:{
                     System.out.print("Enter Element To Add : ");
                     int data = sc.nextInt();
                     s.push(data);
                     break;
                }
                case 2:{
                    int popped = s.pop();
                    if(popped != -1){
                        System.out.print("Popped Element: "+popped);
                    }
                    break;
                }
                case 3:{
                    int peeked = s.peek();
                    if(peeked != -1){
                        System.out.println("Peeked element"+peeked);
                    }
                    break;
                }
                case 4:{
                    System.out.println("Size of Stack:"+s.size());
                    break;
                }
                case 5:{
                    System.out.println("Is stack empty: "+ s.empty());
                    break;
                }
                case 6:{
                    s.printStack();
                    break;
                }
                default:
                    System.out.println("Wrong input");
                    break;
            }
            System.out.println("Do you Want To Continue? (Y/N)");
            ch = sc.next().charAt(0);
        }while( ch == 'y' || ch == 'Y');
    }
}